#!/bin/bash
# CUBE i10-WL 触屏校准脚本 (X11 专用)
#
# 说明: 内核修复(silead_fix.ko)后坐标原生正确, 本脚本仅确保
#       校准矩阵为恒等(identity), 防止系统残留旧的错误校准配置。
# 依赖: X11 + xinput (Wayland 下不可用)
#
# 用法: 手动执行, 或加入 ~/.xprofile 实现登录自动运行

LOG=~/.config/touchscreen-calibrate.log
# Wayland 会话检测（X11 专用，Wayland 下 xinput 不可用）
if [ "$XDG_SESSION_TYPE" = "wayland" ]; then
    echo "警告：当前为 Wayland 会话，xinput 不可用。请切换至 X11 或使用 GNOME 设置校准。"
    exit 0
fi

# 等待 X 就绪和触屏设备出现
for i in $(seq 1 30); do
    DEV_ID=$(DISPLAY=:0 xinput list 2>/dev/null | grep silead_ts | grep -oE 'id=[0-9]+' | head -1 | cut -d= -f2)
    if [ -n "$DEV_ID" ]; then
        sleep 3
        # 应用恒等矩阵（确保无旧校准残留）
        DISPLAY=:0 xinput set-prop $DEV_ID 'libinput Calibration Matrix' 1.0 0.0 0.0 0.0 1.0 0.0 0.0 0.0 1.0
        echo "$(date) 已确认恒等矩阵 (设备ID=$DEV_ID)" >> $LOG
        exit 0
    fi
    sleep 1
done
echo "$(date) 未找到触屏设备" >> $LOG
