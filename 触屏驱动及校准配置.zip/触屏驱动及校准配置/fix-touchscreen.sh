#!/bin/bash
# CUBE i10-WL 触屏内核修复脚本（自动安装依赖版）
# 安装固件 + 内核模块 + 自动加载配置
# 需要 root 权限运行: sudo ./fix-touchscreen.sh [1|2]
#
# 参数说明:
#   1 (默认) = 参数1: 触摸芯片真实分辨率 1972x1514（坐标原生正确, 推荐）
#   2        = 参数2: 屏幕分辨率 1366x768（备用, 仅当参数1触摸偏移时使用）
#
# 用法示例:
#   sudo ./fix-touchscreen.sh        # 使用参数1 (1972x1514)
#   sudo ./fix-touchscreen.sh 2      # 使用参数2 (1366x768)
#   sudo ./switch-coords.sh 2        # 安装后临时切换（无需重装）

set -e

echo === 触屏内核修复 ===

# ========== 参数选择 ==========
COORD_MODE="${1:-1}"
case "$COORD_MODE" in
    1|1972)
        COORD_MODE=1
        MODULE_SRC_DIR="内核模块源码"          # 参数1: 1972x1514
        echo ">> 使用参数1: 触摸芯片真实分辨率 1972x1514 (推荐)"
        ;;
    2|1366)
        COORD_MODE=2
        MODULE_SRC_DIR="参数2-1366x768"       # 参数2: 1366x768
        echo ">> 使用参数2: 屏幕分辨率 1366x768 (备用)"
        ;;
    *)
        echo "错误: 无效参数 '$COORD_MODE'"
        echo "用法: sudo ./fix-touchscreen.sh [1|2]"
        exit 1
        ;;
esac

# ========== 0. 自动检测并安装编译依赖 ==========
echo [0/4] 检查编译依赖...

NEED_INSTALL=""

# 检查 make
command -v make >/dev/null 2>&1 || NEED_INSTALL="$NEED_INSTALL make"
# 检查 gcc（任一版本）
command -v gcc >/dev/null 2>&1 || NEED_INSTALL="$NEED_INSTALL gcc"
# 检查 gcc-14（内核用 gcc-15 构建，需要 gcc-14+ 支持 -fmin-function-alignment）
command -v gcc-14 >/dev/null 2>&1 || NEED_INSTALL="$NEED_INSTALL gcc-14"
# 检查内核头文件
if [ ! -d "/lib/modules/$(uname -r)/build" ]; then
    NEED_INSTALL="$NEED_INSTALL linux-headers-$(uname -r)"
fi

if [ -n "$NEED_INSTALL" ]; then
    echo "检测到缺少依赖，正在安装:$NEED_INSTALL"
    echo "（需要联网，请确保网络可用）"
    apt-get update
    apt-get install -y build-essential $NEED_INSTALL
    echo "依赖安装完成"
else
    echo "编译依赖已齐全 ✓"
fi

# ========== 1. 安装固件 ==========
echo "[1/4] 安装固件..."
mkdir -p /lib/firmware/silead
cp 固件/mssl1680.fw /lib/firmware/silead/mssl1680.fw
echo "固件已安装: /lib/firmware/silead/mssl1680.fw"

# ========== 2. 编译并安装内核模块 ==========
echo "[2/4] 编译内核模块 ($MODULE_SRC_DIR)..."
cd "$MODULE_SRC_DIR"
make clean >/dev/null 2>&1 || true
make CC=gcc-14 2>/dev/null || make
cp silead_fix.ko /lib/modules/$(uname -r)/extra/
depmod -a
cd ..
echo "内核模块已安装 (参数$COORD_MODE)"

# ========== 3. 配置自动加载 ==========
echo "[3/4] 配置自动加载..."
cp 配置/silead-fix.conf /etc/modprobe.d/
echo "softdep 配置已安装"

# ========== 3.5 预编译模块版本校验 ==========
MODULE_PATH="/lib/modules/$(uname -r)/extra/silead_fix.ko"
if [ -f "$MODULE_PATH" ]; then
    MODULE_VER=$(modinfo "$MODULE_PATH" | grep vermagic | awk '{print $2}')
    KERNEL_VER=$(uname -r)
    if [ "$MODULE_VER" != "$KERNEL_VER" ]; then
        echo "警告：预编译模块内核版本 ($MODULE_VER) 与当前系统 ($KERNEL_VER) 不匹配，将尝试重新编译"
        # 强制重新编译
        cd "$MODULE_SRC_DIR" && make clean && make CC=gcc-14
        cp silead_fix.ko /lib/modules/$(uname -r)/extra/
        depmod -a
    fi
fi

# ========== 4. 加载并验证 ==========
echo "[4/4] 加载驱动..."
modprobe -r silead 2>/dev/null || true
modprobe silead || echo "警告：modprobe silead 失败，请检查 dmesg"

echo ""
echo "=== 内核修复完成！ (参数$COORD_MODE: ${MODULE_SRC_DIR}) ==="
echo "验证触屏:"
echo "  dmesg | grep -i silead    # 应看到 stuck workaround + 固件加载"
echo "  ls /dev/input/ | grep event  # 触屏设备应出现"
echo ""
echo "如需立即生效可重启系统，或检查 dmesg 确认驱动状态"
echo ""
echo "若触摸偏移，可切换参数2:"
echo "  sudo ./switch-coords.sh 2   # 切到 1366x768"
echo "  sudo ./switch-coords.sh 1   # 切回 1972x1514"
