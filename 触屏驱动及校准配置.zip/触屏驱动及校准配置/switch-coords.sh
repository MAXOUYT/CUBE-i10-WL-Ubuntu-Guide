#!/bin/bash
# CUBE i10-WL 触屏坐标参数切换脚本
# 用法: sudo ./switch-coords.sh [1|2]
#   1 = 参数1: 触摸芯片真实分辨率 1972x1514（默认, 坐标原生正确）
#   2 = 参数2: 屏幕分辨率 1366x768（备用, 仅当参数1触摸偏移时使用）
#
# 原理: 替换 /lib/modules/$(uname -r)/extra/silead_fix.ko 后重载驱动
# 注意: 本脚本从解压目录运行, 依赖 内核模块源码/ 与 参数2-1366x768/ 目录

set -e

MODE="${1:-1}"
KERNEL=$(uname -r)

case "$MODE" in
    1|1972)
        SRC_DIR="内核模块源码"
        DESC="参数1: 1972x1514 (触摸芯片真实分辨率)"
        ;;
    2|1366)
        SRC_DIR="参数2-1366x768"
        DESC="参数2: 1366x768 (屏幕分辨率, 备用)"
        ;;
    *)
        echo "用法: sudo ./switch-coords.sh [1|2]"
        echo "  1 = 1972x1514 (默认, 推荐)"
        echo "  2 = 1366x768 (备用)"
        exit 1
        ;;
esac

if [ ! -d "$SRC_DIR" ]; then
    echo "错误: 找不到目录 $SRC_DIR"
    echo "请确保在解压后的 触屏驱动及校准配置/ 目录下运行"
    exit 1
fi

echo ">> 切换到 $DESC"

# 优先使用预编译 .ko；若内核版本不匹配则重新编译
echo "[1/3] 安装模块..."
KO_FILE="$SRC_DIR/silead_fix.ko"
if [ -f "$KO_FILE" ]; then
    MODULE_VER=$(modinfo "$KO_FILE" 2>/dev/null | grep vermagic | awk '{print $2}')
    KERNEL_VER=$(uname -r)
    if [ "$MODULE_VER" = "$KERNEL_VER" ]; then
        echo "使用预编译模块 (内核版本匹配: $KERNEL_VER)"
        cp "$KO_FILE" /lib/modules/$KERNEL/extra/silead_fix.ko
    else
        echo "预编译模块内核 ($MODULE_VER) 与当前 ($KERNEL_VER) 不匹配, 重新编译..."
        cd "$SRC_DIR" && make clean >/dev/null 2>&1 || true
        make CC=gcc-14 2>/dev/null || make
        cp silead_fix.ko /lib/modules/$KERNEL/extra/
        cd ..
    fi
else
    echo "未找到预编译模块, 直接编译..."
    cd "$SRC_DIR" && make clean >/dev/null 2>&1 || true
    make CC=gcc-14 2>/dev/null || make
    cp silead_fix.ko /lib/modules/$KERNEL/extra/
    cd ..
fi
depmod -a

echo "[2/3] 重载驱动..."
modprobe -r silead_fix 2>/dev/null || true
modprobe -r silead 2>/dev/null || true
sleep 1
modprobe silead_fix 2>/dev/null || true
modprobe silead || echo "警告: modprobe silead 失败"

echo "[3/3] 完成!"
echo "当前参数: $DESC"
dmesg 2>/dev/null | grep -i silead_fix | tail -1 || true
echo ""
echo "验证触摸: 若仍偏移, 可尝试另一个参数"
echo "  sudo ./switch-coords.sh $([ "$MODE" = "1" ] && echo 2 || echo 1)"
