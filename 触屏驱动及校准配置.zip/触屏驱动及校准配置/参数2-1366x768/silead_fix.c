#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/i2c.h>
#include <linux/property.h>
#include <linux/device.h>

/* GPL-exported symbol, not declared in public headers */
extern int device_create_managed_software_node(struct device *dev,
				const struct property_entry *properties,
				const struct software_node *parent);

static const struct property_entry silead_props[] = {
	PROPERTY_ENTRY_BOOL("silead,stuck-controller-bug"),
	PROPERTY_ENTRY_U32("touchscreen-size-x", 1366),
	PROPERTY_ENTRY_U32("touchscreen-size-y", 768),
	{ }
};

static int __init silead_fix_init(void)
{
	struct device *dev;
	int ret;

	dev = bus_find_device_by_name(&i2c_bus_type, NULL,
				      "i2c-MSSL1680:00");
	if (!dev) {
		pr_err("silead_fix: device i2c-MSSL1680:00 not found\n");
		return -ENODEV;
	}

	ret = device_create_managed_software_node(dev, silead_props, NULL);
	if (ret) {
		pr_err("silead_fix: failed to add properties: %d\n", ret);
		put_device(dev);
		return ret;
	}

	put_device(dev);
	pr_info("silead_fix: stuck + size properties injected (1366x768)\n");
	return 0;
}

static void __exit silead_fix_exit(void)
{
	pr_info("silead_fix: unloaded\n");
}

module_init(silead_fix_init);
module_exit(silead_fix_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Inject silead properties for CUBE i10-WL touchscreen");

